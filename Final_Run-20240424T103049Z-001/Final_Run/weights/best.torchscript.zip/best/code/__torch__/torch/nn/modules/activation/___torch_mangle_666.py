class SiLU(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.nn.modules.activation.___torch_mangle_666.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward1(self: __torch__.torch.nn.modules.activation.___torch_mangle_666.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward2(self: __torch__.torch.nn.modules.activation.___torch_mangle_666.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward3(self: __torch__.torch.nn.modules.activation.___torch_mangle_666.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward4(self: __torch__.torch.nn.modules.activation.___torch_mangle_666.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward5(self: __torch__.torch.nn.modules.activation.___torch_mangle_666.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward6(self: __torch__.torch.nn.modules.activation.___torch_mangle_666.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward7(self: __torch__.torch.nn.modules.activation.___torch_mangle_666.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward8(self: __torch__.torch.nn.modules.activation.___torch_mangle_666.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward9(self: __torch__.torch.nn.modules.activation.___torch_mangle_666.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward10(self: __torch__.torch.nn.modules.activation.___torch_mangle_666.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward11(self: __torch__.torch.nn.modules.activation.___torch_mangle_666.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward12(self: __torch__.torch.nn.modules.activation.___torch_mangle_666.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward13(self: __torch__.torch.nn.modules.activation.___torch_mangle_666.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward14(self: __torch__.torch.nn.modules.activation.___torch_mangle_666.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward15(self: __torch__.torch.nn.modules.activation.___torch_mangle_666.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward16(self: __torch__.torch.nn.modules.activation.___torch_mangle_666.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward17(self: __torch__.torch.nn.modules.activation.___torch_mangle_666.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward18(self: __torch__.torch.nn.modules.activation.___torch_mangle_666.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward19(self: __torch__.torch.nn.modules.activation.___torch_mangle_666.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward20(self: __torch__.torch.nn.modules.activation.___torch_mangle_666.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward21(self: __torch__.torch.nn.modules.activation.___torch_mangle_666.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward22(self: __torch__.torch.nn.modules.activation.___torch_mangle_666.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward23(self: __torch__.torch.nn.modules.activation.___torch_mangle_666.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward24(self: __torch__.torch.nn.modules.activation.___torch_mangle_666.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)
  def forward25(self: __torch__.torch.nn.modules.activation.___torch_mangle_666.SiLU,
    argument_1: Tensor) -> Tensor:
    return torch.silu_(argument_1)

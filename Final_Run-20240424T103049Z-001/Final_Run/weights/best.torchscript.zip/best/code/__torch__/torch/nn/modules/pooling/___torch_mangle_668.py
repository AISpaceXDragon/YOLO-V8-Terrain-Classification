class AdaptiveAvgPool2d(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.nn.modules.pooling.___torch_mangle_668.AdaptiveAvgPool2d,
    argument_1: Tensor) -> Tensor:
    _0 = torch.adaptive_avg_pool2d(argument_1, [1, 1])
    return _0

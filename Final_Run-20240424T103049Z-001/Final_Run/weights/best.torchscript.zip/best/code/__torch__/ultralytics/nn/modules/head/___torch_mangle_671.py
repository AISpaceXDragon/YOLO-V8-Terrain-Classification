class Classify(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv : __torch__.ultralytics.nn.modules.conv.___torch_mangle_667.Conv
  pool : __torch__.torch.nn.modules.pooling.___torch_mangle_668.AdaptiveAvgPool2d
  drop : __torch__.torch.nn.modules.dropout.___torch_mangle_669.Dropout
  linear : __torch__.torch.nn.modules.linear.___torch_mangle_670.Linear
  def forward(self: __torch__.ultralytics.nn.modules.head.___torch_mangle_671.Classify,
    argument_1: Tensor) -> Tensor:
    linear = self.linear
    drop = self.drop
    pool = self.pool
    conv = self.conv
    _0 = (pool).forward((conv).forward(argument_1, ), )
    input = torch.flatten(_0, 1)
    _1 = (linear).forward((drop).forward(input, ), )
    return torch.softmax(_1, 1)
